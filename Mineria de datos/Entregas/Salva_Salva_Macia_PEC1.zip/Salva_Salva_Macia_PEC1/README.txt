# README - Entrega de la Práctica

Este repositorio contiene los archivos entregados correspondientes a la Práctica. A continuación, se detalla el contenido de cada uno de ellos:

## Archivos Incluidos

1. **Salva_Salva_Macia.pdf**  
   - Este archivo es un documento en formato PDF generado a partir de un documento Word.
   - Contiene la explicación detallada del resultado de la práctica.


3. **PEC1.ipynb**
   - Este es el archivo del notebook original (en formato `.ipynb`) utilizado para realizar la práctica.
  - Incluye una sección adicional que describe la elección del dataset utilizado.

 

